# animal_shelter.py
# CS340 SNHU
# Stacey Griggs

from pymongo import MongoClient  # Import MongoDB client
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operation for Animal collection in MongoDB"""
    
    def __init__(self, user, password, host, port, db, collection):
        """Initialize MongoDB connection"""
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.db = db
        self.collection_name = collection
        
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{self.user}:{self.password}@{self.host}:{self.port}')
        self.database = self.client[self.db]
        self.collection = self.database[self.collection_name]
        
    def create(self, data):
        """Insert a document into the MongoDB collection."""
        if data:
            try:
                result = self.collection.insert_one(data)  # Insert document into the collection
                return True if result.inserted_id else False
            except Exception as e:
                print(f"An error occurred: {str(e)}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")
        
    def read(self, query):
        """Retrieve documents based on the provided query."""
        try:
            cursor = self.collection.find(query)
            result = list(cursor)  # Convert cursor to list
            return result if result else []
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return []