package com.weighttracker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

// CreateAccountActivity.java
public class CreateAccountActivity extends AppCompatActivity {

    // UI elements
    private EditText usernameEditText, passwordEditText;
    // Button to create account
    private Button createAccountButton;

    // onCreate method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        usernameEditText = findViewById(R.id.username_create);
        passwordEditText = findViewById(R.id.password_create);
        createAccountButton = findViewById(R.id.create_account_button);

        createAccountButton.setOnClickListener(v -> {
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
            sharedPreferences.edit()
                    .putString("username", usernameEditText.getText().toString())
                    .putString("password", passwordEditText.getText().toString())
                    .apply();

            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}