package com.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

// DatabaseHelper.java
public class DatabaseHelper extends SQLiteOpenHelper {

    // Constants
    private static final String TAG = "DatabaseHelper";

    // Database Info
    private static final String DATABASE_NAME = "weight_tracker.db";
    //
    private static final int DATABASE_VERSION = 1;

    // Table Names
    private static final String TABLE_WEIGHTS = "weights";

    // Weights Table Columns
    private static final String KEY_WEIGHT_ID = "_id";
    // Weight value and date
    private static final String KEY_WEIGHT_VALUE = "weight_value";
    // Date of the weight entry
    private static final String KEY_WEIGHT_DATE = "weight_date";

    // SQL for creating the weights table
    private static final String CREATE_TABLE_WEIGHTS =
            "CREATE TABLE " + TABLE_WEIGHTS + "(" +
                    KEY_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    KEY_WEIGHT_VALUE + " REAL," +
                    KEY_WEIGHT_DATE + " TEXT" +
                    ")";

    //
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_WEIGHTS);
        Log.d(TAG, "onCreate: Table created");
    }

    // Called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
            onCreate(db);
        }
    }

    // Add a new weight entry
    public long addWeight(double weightValue, String weightDate) {
        SQLiteDatabase db = getWritableDatabase();
        long rowId = -1;
        try {
            db.beginTransaction();
            ContentValues values = new ContentValues();
            values.put(KEY_WEIGHT_VALUE, weightValue);
            values.put(KEY_WEIGHT_DATE, weightDate);

            rowId = db.insertOrThrow(TABLE_WEIGHTS, null, values);
            db.setTransactionSuccessful();
            Log.d(TAG, "addWeight: Weight added");
        } catch (Exception e) {
            Log.e(TAG, "Error while trying to add weight to database", e);
        } finally {
            db.endTransaction();
        }
        return rowId;
    }

    // Get all weight entries
    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            String WEIGHTS_SELECT_QUERY =
                    String.format("SELECT * FROM %s", TABLE_WEIGHTS);
            cursor = db.rawQuery(WEIGHTS_SELECT_QUERY, null);
            Log.d(TAG, "getAllWeights: Weights retrieved");
        } catch (Exception e) {
            Log.e(TAG, "Error while trying to get weights from database", e);
        }
        return cursor;  // It's important to close the cursor after use
    }

    // Safely close the cursor to prevent memory leaks
    public void closeCursor(Cursor cursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
            Log.d(TAG, "closeCursor: Cursor closed");
        }
    }

    // Delete a weight entry by ID
    public int deleteWeight(long weightId) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = 0;
        try {
            db.beginTransaction();
            rowsDeleted = db.delete(TABLE_WEIGHTS, KEY_WEIGHT_ID + "= ?", new String[]{String.valueOf(weightId)});
            db.setTransactionSuccessful();
            Log.d(TAG, "deleteWeight: Weight deleted");
        } catch (Exception e) {
            Log.e(TAG, "Error while trying to delete weight from database", e);
        } finally {
            db.endTransaction();
        }
        return rowsDeleted;
    }
}
