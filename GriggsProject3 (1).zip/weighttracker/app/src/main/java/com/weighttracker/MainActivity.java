package com.weighttracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

// MainActivity is the main activity of the application
public class MainActivity extends AppCompatActivity {

    //
    private List<String> weightList;
    // WeightAdapter will display a list of weights
    private WeightAdapter weightAdapter;
    // UI elements
    private EditText enterWeightEditText;
    // Button to add weight
    private Button addWeightButton;
    // RecyclerView to show entered values
    private RecyclerView recyclerViewWeights;
    // Button to request SMS permission
    private Button requestSmsPermissionButton;
    // Request code for SMS permission
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    // onCreate method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the list of weights
        weightList = new ArrayList<>();

        // Initialize UI elements
        enterWeightEditText = findViewById(R.id.enter_weight);
        addWeightButton = findViewById(R.id.add_weight);
        requestSmsPermissionButton = findViewById(R.id.request_sms_permission);
        recyclerViewWeights = findViewById(R.id.recyclerViewWeights);

        // Set up RecyclerView
        weightAdapter = new WeightAdapter(weightList);
        recyclerViewWeights.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewWeights.setAdapter(weightAdapter);

        // Set onClickListener for addWeightButton
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = enterWeightEditText.getText().toString();
                if (!weight.isEmpty()) {
                    weightList.add(weight);
                    weightAdapter.notifyItemInserted(weightList.size() - 1);
                    enterWeightEditText.setText("");
                } else {
                    Toast.makeText(MainActivity.this, getString(R.string.please_enter_weight), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set onClickListener for requestSmsPermissionButton
        requestSmsPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });
    }

    // requestSmsPermission method
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission is already granted, proceed with SMS functionality
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    // onRequestPermissionsResult method
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with SMS functionality
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}