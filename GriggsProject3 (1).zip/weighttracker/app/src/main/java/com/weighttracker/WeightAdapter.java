package com.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// WeightAdapter will display a list of weights
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final List<String> weightList;

    // Constructor
    public WeightAdapter(List<String> weightList) {
        this.weightList = weightList;
    }

    // Called when RecyclerView needs a new ViewHolder of the given type to represent an item.
    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new WeightViewHolder(view);
    }

    // Bind data to ViewHolder
    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        String weight = weightList.get(position);
        holder.weightTextView.setText(weight);
    }

    // Return the number of items in the list
    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // ViewHolder class
    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        // UI elements
        public TextView weightTextView;

        // Constructor
        public WeightViewHolder(View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
        }
    }
}